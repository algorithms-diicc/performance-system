#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

static void free_lines(char **lines, size_t count) {
    for (size_t i = 0; i < count; ++i) {
        free(lines[i]);
    }
    free(lines);
}

static int append_line(
    char ***lines,
    size_t *count,
    size_t *capacity,
    const char *value
) {
    if (*count == *capacity) {
        const size_t next_capacity = *capacity == 0 ? 16 : *capacity * 2;
        char **resized = realloc(*lines, next_capacity * sizeof(*resized));
        if (resized == NULL) {
            return 0;
        }
        *lines = resized;
        *capacity = next_capacity;
    }

    const size_t length = strlen(value);
    (*lines)[*count] = malloc(length + 1);
    if ((*lines)[*count] == NULL) {
        return 0;
    }

    memcpy((*lines)[*count], value, length + 1);
    ++(*count);
    return 1;
}

static size_t lcs_length(
    char *const *first,
    size_t first_count,
    char *const *second,
    size_t second_count
) {
    char *const *rows = first;
    char *const *cols = second;
    size_t row_count = first_count;
    size_t col_count = second_count;

    if (col_count > row_count) {
        rows = second;
        cols = first;
        row_count = second_count;
        col_count = first_count;
    }

    size_t *previous = calloc(col_count + 1, sizeof(*previous));
    size_t *current = calloc(col_count + 1, sizeof(*current));
    if (previous == NULL || current == NULL) {
        free(previous);
        free(current);
        return 0;
    }

    for (size_t i = 0; i < row_count; ++i) {
        current[0] = 0;
        for (size_t j = 1; j <= col_count; ++j) {
            if (strcmp(rows[i], cols[j - 1]) == 0) {
                current[j] = previous[j - 1] + 1;
            } else {
                current[j] = previous[j] > current[j - 1]
                    ? previous[j]
                    : current[j - 1];
            }
        }

        size_t *swap = previous;
        previous = current;
        current = swap;
    }

    const size_t result = previous[col_count];
    free(previous);
    free(current);
    return result;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Uso: longest_common_subsequence <archivo_input>\n");
        return 1;
    }

    FILE *input = fopen(argv[1], "r");
    if (input == NULL) {
        return 1;
    }

    char **lines = NULL;
    size_t line_count = 0;
    size_t capacity = 0;
    char *buffer = NULL;
    size_t buffer_size = 0;
    ssize_t read = 0;

    while ((read = getline(&buffer, &buffer_size, input)) != -1) {
        if (read > 0 && buffer[read - 1] == '\n') {
            buffer[read - 1] = '\0';
        }
        if (!append_line(&lines, &line_count, &capacity, buffer)) {
            free(buffer);
            fclose(input);
            free_lines(lines, line_count);
            return 1;
        }
    }

    free(buffer);
    fclose(input);

    const size_t middle = line_count / 2;
    const size_t length = lcs_length(
        lines,
        middle,
        lines + middle,
        line_count - middle
    );

    /* Salida observable: el benchmark redirige stdout durante la medición. */
    printf("%zu\n", length);
    free_lines(lines, line_count);
    return 0;
}
