#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>

std::vector<int> make_input(int n) {
    std::vector<int> values;
    values.reserve(static_cast<std::size_t>(n));

    std::uint32_t state = 0x12345678u;
    for (int i = 0; i < n; ++i) {
        state = state * 1664525u + 1013904223u;
        values.push_back(static_cast<int>(state & 0x7fffffffu));
    }

    return values;
}

void insertion_sort(std::vector<int>& values) {
    for (std::size_t i = 1; i < values.size(); ++i) {
        const int key = values[i];
        std::size_t j = i;

        while (j > 0 && values[j - 1] > key) {
            values[j] = values[j - 1];
            --j;
        }

        values[j] = key;
    }
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Uso: insertion_sort <N>\n";
        return 1;
    }

    const long parsed = std::strtol(argv[1], nullptr, 10);
    if (parsed <= 0) {
        return 1;
    }

    auto values = make_input(static_cast<int>(parsed));
    insertion_sort(values);

    // Salida observable para impedir que el compilador elimine el trabajo.
    std::uint64_t checksum = 0;
    for (int value : values) {
        checksum = checksum * 1315423911u + static_cast<std::uint32_t>(value);
    }

    std::cout << checksum << '\n';
    return 0;
}
