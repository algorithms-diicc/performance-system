#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>

static std::size_t requested_size(int argc, char **argv) {
    unsigned long long best = 0;
    for (int i = 1; i < argc; ++i) {
        char *end = nullptr;
        errno = 0;
        const auto value = std::strtoull(argv[i], &end, 10);
        if (errno == 0 && end != argv[i] && *end == '\0' && value > best) {
            best = value;
        }
    }
    if (best == 0) best = 500;
    if (best > 2000) best = 2000;
    return static_cast<std::size_t>(best);
}

static std::string sequence(std::size_t n, std::size_t shift) {
    static const char alphabet[] = "ACGTGCACTGAC";
    constexpr std::size_t width = sizeof(alphabet) - 1;
    std::string result(n, 'A');
    for (std::size_t i = 0; i < n; ++i) {
        result[i] = alphabet[(i * 7 + shift) % width];
    }
    return result;
}

static bool load_dataset_sequences(
    int argc,
    char **argv,
    std::size_t n,
    std::string &a,
    std::string &b
) {
    for (int i = 1; i < argc; ++i) {
        std::ifstream input(argv[i], std::ios::binary);
        if (!input) continue;
        std::string data(2 * n, '\0');
        input.read(data.data(), static_cast<std::streamsize>(data.size()));
        if (input.gcount() >= static_cast<std::streamsize>(data.size())) {
            a.assign(data.data(), n);
            b.assign(data.data() + n, n);
            return true;
        }
    }
    return false;
}

int main(int argc, char **argv) {
    const std::size_t n = requested_size(argc, argv);
    std::string a;
    std::string b;
    if (!load_dataset_sequences(argc, argv, n, a, b)) {
        a = sequence(n, 0);
        b = sequence(n, 3);
    }
    std::vector<unsigned int> previous(n + 1, 0);
    std::vector<unsigned int> current(n + 1, 0);

    for (std::size_t i = 1; i <= n; ++i) {
        current[0] = 0;
        for (std::size_t j = 1; j <= n; ++j) {
            if (a[i - 1] == b[j - 1]) {
                current[j] = previous[j - 1] + 1;
            } else {
                current[j] = std::max(previous[j], current[j - 1]);
            }
        }
        previous.swap(current);
    }

    std::printf("lcs=%u n=%zu\n", previous[n], n);
    return 0;
}
