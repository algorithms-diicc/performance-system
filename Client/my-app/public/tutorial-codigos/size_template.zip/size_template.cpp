
#include <iostream>
#include <cstdlib>

long long iterativeFibonacci(int n) {
    if (n <= 1) return n;
    long long a = 0, b = 1, c;
    for (int i = 2; i <= n; ++i) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}

int main(int argc, char* argv[]) {
    if (argc < 2) return 1;
    int num = std::atoi(argv[1]);
    iterativeFibonacci(num);
    return 0;
}
