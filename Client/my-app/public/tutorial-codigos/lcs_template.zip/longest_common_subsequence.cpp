#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

std::size_t lcs_length(
    const std::vector<std::string>& first,
    const std::vector<std::string>& second
) {
    // Programación dinámica con dos filas: O(n*m) tiempo y O(m) memoria.
    const std::vector<std::string>* rows = &first;
    const std::vector<std::string>* cols = &second;

    if (cols->size() > rows->size()) {
        std::swap(rows, cols);
    }

    std::vector<std::size_t> previous(cols->size() + 1, 0);
    std::vector<std::size_t> current(cols->size() + 1, 0);

    for (const std::string& left : *rows) {
        current[0] = 0;

        for (std::size_t j = 1; j <= cols->size(); ++j) {
            if (left == (*cols)[j - 1]) {
                current[j] = previous[j - 1] + 1;
            } else {
                current[j] = std::max(previous[j], current[j - 1]);
            }
        }

        std::swap(previous, current);
    }

    return previous.back();
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Uso: longest_common_subsequence <archivo_input>\n";
        return 1;
    }

    std::ifstream input(argv[1]);
    if (!input) {
        return 1;
    }

    std::vector<std::string> lines;
    std::string line;

    while (std::getline(input, line)) {
        lines.push_back(line);
    }

    const std::size_t middle = lines.size() / 2;

    std::vector<std::string> first(
        lines.begin(),
        lines.begin() + static_cast<std::ptrdiff_t>(middle)
    );
    std::vector<std::string> second(
        lines.begin() + static_cast<std::ptrdiff_t>(middle),
        lines.end()
    );

    const std::size_t length = lcs_length(first, second);

    // Salida observable: el benchmark redirige stdout durante la medición.
    std::cout << length << '\n';
    return 0;
}
