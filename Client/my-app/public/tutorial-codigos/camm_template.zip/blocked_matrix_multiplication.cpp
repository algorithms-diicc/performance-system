#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <vector>

constexpr std::size_t BLOCK_SIZE = 32;

void blocked_multiply(
    const std::vector<double>& a,
    const std::vector<double>& b,
    std::vector<double>& c,
    std::size_t n
) {
    for (std::size_t ii = 0; ii < n; ii += BLOCK_SIZE) {
        for (std::size_t kk = 0; kk < n; kk += BLOCK_SIZE) {
            for (std::size_t jj = 0; jj < n; jj += BLOCK_SIZE) {
                const std::size_t i_end = std::min(ii + BLOCK_SIZE, n);
                const std::size_t k_end = std::min(kk + BLOCK_SIZE, n);
                const std::size_t j_end = std::min(jj + BLOCK_SIZE, n);

                for (std::size_t i = ii; i < i_end; ++i) {
                    for (std::size_t k = kk; k < k_end; ++k) {
                        const double aik = a[i * n + k];

                        for (std::size_t j = jj; j < j_end; ++j) {
                            c[i * n + j] += aik * b[k * n + j];
                        }
                    }
                }
            }
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        return 1;
    }

    const std::size_t value_count = static_cast<std::size_t>(argc - 1);
    const std::size_t matrix_size = static_cast<std::size_t>(
        std::sqrt(static_cast<double>(value_count / 2))
    );

    if (matrix_size == 0) {
        return 1;
    }

    const std::size_t values_per_matrix = matrix_size * matrix_size;
    std::vector<double> a(values_per_matrix);
    std::vector<double> b(values_per_matrix);
    std::vector<double> c(values_per_matrix, 0.0);

    for (std::size_t i = 0; i < values_per_matrix; ++i) {
        a[i] = std::strtod(argv[1 + i], nullptr);
        b[i] = std::strtod(argv[1 + values_per_matrix + i], nullptr);
    }

    blocked_multiply(a, b, c, matrix_size);

    // Checksum observable para conservar el cálculo bajo optimización.
    double checksum = 0.0;
    for (double value : c) {
        checksum += value;
    }

    std::cout << checksum << '\n';
    return 0;
}
