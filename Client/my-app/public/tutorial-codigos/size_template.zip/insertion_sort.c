#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

static int *make_input(size_t n) {
    int *values = malloc(n * sizeof(*values));
    if (values == NULL) {
        return NULL;
    }

    uint32_t state = UINT32_C(0x12345678);
    for (size_t i = 0; i < n; ++i) {
        state = state * UINT32_C(1664525) + UINT32_C(1013904223);
        values[i] = (int)(state & UINT32_C(0x7fffffff));
    }

    return values;
}

static void insertion_sort(int *values, size_t length) {
    for (size_t i = 1; i < length; ++i) {
        const int key = values[i];
        size_t j = i;

        while (j > 0 && values[j - 1] > key) {
            values[j] = values[j - 1];
            --j;
        }

        values[j] = key;
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Uso: insertion_sort <N>\n");
        return 1;
    }

    char *end = NULL;
    const long parsed = strtol(argv[1], &end, 10);
    if (parsed <= 0 || end == argv[1] || *end != '\0') {
        return 1;
    }

    const size_t length = (size_t)parsed;
    int *values = make_input(length);
    if (values == NULL) {
        return 1;
    }

    insertion_sort(values, length);

    /* Salida observable para impedir que el compilador elimine el trabajo. */
    uint64_t checksum = 0;
    for (size_t i = 0; i < length; ++i) {
        checksum = checksum * UINT32_C(1315423911) + (uint32_t)values[i];
    }

    printf("%" PRIu64 "\n", checksum);
    free(values);
    return 0;
}
