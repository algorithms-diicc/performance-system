#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

static size_t requested_size(int argc, char **argv) {
    unsigned long long best = 0;
    for (int i = 1; i < argc; ++i) {
        char *end = NULL;
        errno = 0;
        unsigned long long value = strtoull(argv[i], &end, 10);
        if (errno == 0 && end != argv[i] && *end == '\0' && value > best) {
            best = value;
        }
    }
    if (best == 0) best = 2500;
    if (best > 20000) best = 20000;
    return (size_t)best;
}

int main(int argc, char **argv) {
    const size_t n = requested_size(argc, argv);
    uint64_t *values = malloc(n * sizeof(*values));
    if (!values) return 2;

    for (size_t i = 0; i < n; ++i) values[i] = (uint64_t)(2 * i + 1);
    if (n > 1) values[n - 1] = values[n / 2];

    uint64_t duplicate = values[0];
    int found = 0;
    for (size_t i = 0; i < n && !found; ++i) {
        for (size_t j = i + 1; j < n; ++j) {
            if (values[i] == values[j]) {
                duplicate = values[i];
                found = 1;
                break;
            }
        }
    }

    printf("duplicate=%llu n=%zu\n", (unsigned long long)duplicate, n);
    free(values);
    return found ? 0 : 3;
}
