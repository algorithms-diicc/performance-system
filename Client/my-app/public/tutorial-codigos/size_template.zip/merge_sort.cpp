#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>

std::vector<int> make_input(int n) {
    std::vector<int> values;
    values.reserve(static_cast<std::size_t>(n));

    std::uint32_t state = 0x12345678u;
    for (int i = 0; i < n; ++i) {
        state = state * 1664525u + 1013904223u;
        values.push_back(static_cast<int>(state & 0x7fffffffu));
    }

    return values;
}

void merge_ranges(
    std::vector<int>& values,
    std::vector<int>& buffer,
    std::size_t left,
    std::size_t middle,
    std::size_t right
) {
    std::size_t i = left;
    std::size_t j = middle;
    std::size_t k = left;

    while (i < middle && j < right) {
        if (values[i] <= values[j]) {
            buffer[k++] = values[i++];
        } else {
            buffer[k++] = values[j++];
        }
    }

    while (i < middle) {
        buffer[k++] = values[i++];
    }

    while (j < right) {
        buffer[k++] = values[j++];
    }

    for (std::size_t pos = left; pos < right; ++pos) {
        values[pos] = buffer[pos];
    }
}

void merge_sort_impl(
    std::vector<int>& values,
    std::vector<int>& buffer,
    std::size_t left,
    std::size_t right
) {
    if (right - left <= 1) {
        return;
    }

    const std::size_t middle = left + (right - left) / 2;
    merge_sort_impl(values, buffer, left, middle);
    merge_sort_impl(values, buffer, middle, right);
    merge_ranges(values, buffer, left, middle, right);
}

void merge_sort(std::vector<int>& values) {
    std::vector<int> buffer(values.size());
    merge_sort_impl(values, buffer, 0, values.size());
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Uso: merge_sort <N>\n";
        return 1;
    }

    const long parsed = std::strtol(argv[1], nullptr, 10);
    if (parsed <= 0) {
        return 1;
    }

    auto values = make_input(static_cast<int>(parsed));
    merge_sort(values);

    // Mismo checksum que insertion_sort.cpp sobre el mismo input.
    std::uint64_t checksum = 0;
    for (int value : values) {
        checksum = checksum * 1315423911u + static_cast<std::uint32_t>(value);
    }

    std::cout << checksum << '\n';
    return 0;
}
