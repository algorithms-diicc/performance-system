#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

static std::size_t requested_size(int argc, char **argv) {
    unsigned long long best = 0;
    for (int i = 1; i < argc; ++i) {
        char *end = nullptr;
        errno = 0;
        const auto value = std::strtoull(argv[i], &end, 10);
        if (errno == 0 && end != argv[i] && *end == '\0' && value > best) {
            best = value;
        }
    }
    if (best == 0) best = 2500;
    if (best > 20000) best = 20000;
    return static_cast<std::size_t>(best);
}

int main(int argc, char **argv) {
    const std::size_t n = requested_size(argc, argv);
    std::vector<std::uint64_t> values(n);
    for (std::size_t i = 0; i < n; ++i) values[i] = 2 * i + 1;
    if (n > 1) values[n - 1] = values[n / 2];

    std::sort(values.begin(), values.end());
    std::uint64_t duplicate = values.front();
    bool found = false;
    for (std::size_t i = 1; i < n; ++i) {
        if (values[i - 1] == values[i]) {
            duplicate = values[i];
            found = true;
            break;
        }
    }

    std::printf("duplicate=%llu n=%zu\n",
                static_cast<unsigned long long>(duplicate), n);
    return found ? 0 : 3;
}
