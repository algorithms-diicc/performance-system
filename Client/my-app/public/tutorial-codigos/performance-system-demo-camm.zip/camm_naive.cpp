#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <vector>

static std::size_t requested_values(int argc, char **argv) {
    unsigned long long best = 0;
    for (int i = 1; i < argc; ++i) {
        char *end = nullptr;
        errno = 0;
        const auto value = std::strtoull(argv[i], &end, 10);
        if (errno == 0 && end != argv[i] && *end == '\0' && value > best) {
            best = value;
        }
    }
    if (best == 0) best = 5000;
    return static_cast<std::size_t>(best);
}

static std::size_t matrix_dimension(std::size_t values) {
    std::size_t n = static_cast<std::size_t>(std::sqrt(values / 2.0));
    if (n < 8) n = 8;
    if (n > 256) n = 256;
    return n;
}

static bool load_dataset_matrices(
    int argc,
    char **argv,
    std::vector<double> &a,
    std::vector<double> &b
) {
    for (int i = 1; i < argc; ++i) {
        std::ifstream input(argv[i]);
        if (!input) continue;
        std::vector<double> candidate_a(a.size());
        std::vector<double> candidate_b(b.size());
        bool complete = true;
        for (double &value : candidate_a) complete = complete && bool(input >> value);
        for (double &value : candidate_b) complete = complete && bool(input >> value);
        if (complete) {
            a.swap(candidate_a);
            b.swap(candidate_b);
            return true;
        }
    }
    return false;
}

int main(int argc, char **argv) {
    const std::size_t values = requested_values(argc, argv);
    const std::size_t n = matrix_dimension(values);
    std::vector<double> a(n * n), b(n * n), c(n * n, 0.0);

    if (!load_dataset_matrices(argc, argv, a, b)) {
        for (std::size_t i = 0; i < n * n; ++i) {
            a[i] = static_cast<double>((i * 17 + 3) % 101) / 101.0;
            b[i] = static_cast<double>((i * 29 + 7) % 103) / 103.0;
        }
    }

    for (std::size_t i = 0; i < n; ++i) {
        for (std::size_t j = 0; j < n; ++j) {
            double sum = 0.0;
            for (std::size_t k = 0; k < n; ++k) {
                sum += a[i * n + k] * b[k * n + j];
            }
            c[i * n + j] = sum;
        }
    }

    double checksum = 0.0;
    for (double value : c) checksum += value;
    std::printf("checksum=%.9f dimension=%zu values=%zu\n", checksum, n, values);
    return 0;
}
